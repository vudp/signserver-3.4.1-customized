package com.tomicalab.cag360.clientdemo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Security;
import java.security.Signature;
import java.security.SignatureException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Enumeration;

import javax.xml.bind.DatatypeConverter;
import javax.xml.namespace.QName;

import org.apache.commons.io.IOUtils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import vn.mobile_id.trustedhub.clientws.CagCredential;
import vn.mobile_id.trustedhub.clientws.ClientWS;
import vn.mobile_id.trustedhub.clientws.ClientWSService;
import vn.mobile_id.trustedhub.clientws.SSLUtilities;
import vn.mobile_id.trustedhub.clientws.TransactionInfo;

public class ClientDemo {
	static String cagWSurl = "https://mobile-id.vn:9084/TRUSTEDHUB/ClientWSService/ClientWS?wsdl"; // Dia
																									// chi
																									// server
																									// ky
																									// so
	static String p12File = "F:\\Tomica\\svn-project\\CAG360\\Files\\keystore\\trustedhub.p12"; // Client
																								// Certificate
	static String p12Pass = "12345678";

	static String user = "trustedhub";
	static String passwd = "12345678";
	static String signature = "tLA66gWm5qP0sCQp2BtUjhkhjVDRe99UkLHbkTdsjI2lx31T/Z2B2dp4cOsPATGrj6mHcFT4gFKSM1w9hbD+u2ekpYCNcgR8ttuWPNNmn8dHdVPHjDTiQSUogWMmkzjfIX/4oSJG92LeTx4hJ9kat/UILrV7mSvXBoZ8sxR1+g3jXTwU2MJpFrYnDmDZeVoQXSa101jvKFXShtv+o5Zk2S966vrG9X1RdJV9gQ8LTW71MXQgjh5lLNyZlMgJ3Mw6oVAwY1GR+23QoBaZsd9NDtCI7LLyU//3G/xEsaBwKcwZBKvaHcuy4bCPD22Dh0K38+bvEcL0rEqnKGhZIcuS8A==";

	static String FILE_SRC_PDF = "E:\\File\\FileToSign\\ok.pdf";
	static String FILE_DST_PDF = "E:\\File\\FileToSign\\ok_signed.pdf";
	
	static String FILE_SRC_DOC = "E:\\File\\FileToSign\\ok.doc";
	static String FILE_DST_DOC = "E:\\File\\FileToSign\\ok_signed.doc";
	
	static String FILE_SRC_XML = "E:\\File\\FileToSign\\ok.xml";
	static String FILE_DST_XML = "E:\\File\\FileToSign\\ok_signed.xml";

	static String channelName = "TRUSTEDHUB";
	static String customerUser = "msigdemo";

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ClientDemo demo = new ClientDemo();
		
		demo.signPdf();
		demo.verifyPdf();
		
		demo.signOffice();
		demo.verifyOffice();
		
		demo.signXml();
		demo.verifyXml();
		
	}

	private void signPdf() throws Exception {
		String xmlData = "<Channel>" + channelName + "</Channel>\n" + "<User>"
				+ customerUser + "</User>\n" + "<ID>01009090</ID>\n"
				+ "<FileType>pdf</FileType>\n" + "<MetaData>\n"
				+ "  <ExternalStorage>P2P</ExternalStorage>"
				+ "  <Method>SynchronousSign</Method>\n"
				+ "  <PageNo>1</PageNo>\n"
				+ "  <Coordinate>50,500,550,680</Coordinate>\n"
				+ "  <SignReason>Ký lần 2, sếp cho ý kiến</SignReason>\n"
				+ "</MetaData>\n" + "<WorkerName>MultiSigner</WorkerName>";

		// prepare file data
		byte[] fileToSign = IOUtils.toByteArray(new FileInputStream(FILE_SRC_PDF));

		// prepare cagCredential
		String timeStamp = String.valueOf(System.currentTimeMillis());
		String dataToSign = user + passwd + signature + timeStamp;
		String pkcs1Sig = getPKCS1Signature(dataToSign, p12File, p12Pass);

		CagCredential credential = new CagCredential();
		credential.setUsername(user);
		credential.setPassword(passwd);
		credential.setSignature(signature);
		credential.setTimestamp(timeStamp);
		credential.setPkcs1Signature(pkcs1Sig);

		TransactionInfo transReq = new TransactionInfo();
		transReq.setXmlData(xmlData);
		transReq.setFileData(fileToSign);
		transReq.setCredentialData(credential);

		TransactionInfo transRes = getWS().processData(transReq);

		int responseCode = Integer.parseInt(getContent("ResponseCode",
				transRes.getXmlData()));
		if (responseCode == 0) {
			System.out.println("sign success");
			System.out.println("Saved file in " + FILE_DST_PDF);
			System.out.println(transRes.getXmlData());
			IOUtils.write(transRes.getFileData(),
					new FileOutputStream(FILE_DST_PDF));
		} else {
			System.out.println("sign error: " + transRes.getXmlData());
		}
	}

	public void verifyPdf() throws Exception {

		String xmlData = "<Channel>" + channelName + "</Channel>\n" + "<User>"
				+ customerUser + "</User>\n" + "<ID>01009090</ID>\n"
				+ "<MetaData>\n"
				+ "  <ExternalStorage>P2P</ExternalStorage>\n"
				+ "  <SignatureMethod>SPKI</SignatureMethod>\n"
				+ "</MetaData>\n" + "<WorkerName>MultiValidator</WorkerName>";

		// prepare file data
		byte[] fileToSign = IOUtils.toByteArray(new FileInputStream(FILE_DST_PDF));

		// prepare cagCredential
		String timeStamp = String.valueOf(System.currentTimeMillis());
		String pkcs1Sig = getPKCS1Signature(user + passwd + signature
				+ timeStamp, p12File, p12Pass);

		CagCredential credential = new CagCredential();
		credential.setUsername(user);
		credential.setPassword(passwd);
		credential.setSignature(signature);
		credential.setTimestamp(timeStamp);
		credential.setPkcs1Signature(pkcs1Sig);

		TransactionInfo transReq = new TransactionInfo();
		transReq.setXmlData(xmlData);
		transReq.setFileData(fileToSign);
		transReq.setCredentialData(credential);

		TransactionInfo transRes = getWS().processData(transReq);
		int responseCode = Integer.parseInt(getContent("ResponseCode",
				transRes.getXmlData()));
		if (responseCode == 0) {
			System.out.println("verify success");
			System.out.println(transRes.getXmlData());
		} else {
			System.out.println("error: " + transRes.getXmlData());
		}
	}
	
	private void signOffice() throws Exception {
		String xmlData = "<Channel>"+channelName+"</Channel>\n"
	            + "<User>"+customerUser+"</User>\n"
	            + "<ID>01009090</ID>\n"
	            + "<FileType>doc</FileType>\n"
	            + "<MetaData>\n"
	            + "  <ExternalStorage>P2P</ExternalStorage>"
	            + "  <Method>SynchronousSign</Method>\n"
	            + "</MetaData>\n"
	            + "<WorkerName>MultiSigner</WorkerName>";

		// prepare file data
		byte[] fileToSign = IOUtils.toByteArray(new FileInputStream(FILE_SRC_DOC));

		// prepare cagCredential
		String timeStamp = String.valueOf(System.currentTimeMillis());
		String dataToSign = user + passwd + signature + timeStamp;
		String pkcs1Sig = getPKCS1Signature(dataToSign, p12File, p12Pass);

		CagCredential credential = new CagCredential();
		credential.setUsername(user);
		credential.setPassword(passwd);
		credential.setSignature(signature);
		credential.setTimestamp(timeStamp);
		credential.setPkcs1Signature(pkcs1Sig);

		TransactionInfo transReq = new TransactionInfo();
		transReq.setXmlData(xmlData);
		transReq.setFileData(fileToSign);
		transReq.setCredentialData(credential);

		TransactionInfo transRes = getWS().processData(transReq);

		int responseCode = Integer.parseInt(getContent("ResponseCode",
				transRes.getXmlData()));
		if (responseCode == 0) {
			System.out.println("sign success");
			System.out.println("Saved file in " + FILE_DST_DOC);
			System.out.println(transRes.getXmlData());
			IOUtils.write(transRes.getFileData(),
					new FileOutputStream(FILE_DST_DOC));
		} else {
			System.out.println("sign error: " + transRes.getXmlData());
		}
	}
	
	public void verifyOffice() throws Exception {

		String xmlData = "<Channel>" + channelName + "</Channel>\n" + "<User>"
				+ customerUser + "</User>\n" + "<ID>01009090</ID>\n"
				+ "<MetaData>\n"
				+ "  <ExternalStorage>P2P</ExternalStorage>\n"
				+ "  <SignatureMethod>SPKI</SignatureMethod>\n"
				+ "</MetaData>\n" + "<WorkerName>MultiValidator</WorkerName>";

		// prepare file data
		byte[] fileToSign = IOUtils.toByteArray(new FileInputStream(FILE_DST_DOC));

		// prepare cagCredential
		String timeStamp = String.valueOf(System.currentTimeMillis());
		String pkcs1Sig = getPKCS1Signature(user + passwd + signature
				+ timeStamp, p12File, p12Pass);

		CagCredential credential = new CagCredential();
		credential.setUsername(user);
		credential.setPassword(passwd);
		credential.setSignature(signature);
		credential.setTimestamp(timeStamp);
		credential.setPkcs1Signature(pkcs1Sig);

		TransactionInfo transReq = new TransactionInfo();
		transReq.setXmlData(xmlData);
		transReq.setFileData(fileToSign);
		transReq.setCredentialData(credential);

		TransactionInfo transRes = getWS().processData(transReq);
		int responseCode = Integer.parseInt(getContent("ResponseCode",
				transRes.getXmlData()));
		if (responseCode == 0) {
			System.out.println("verify success");
			System.out.println(transRes.getXmlData());
		} else {
			System.out.println("error: " + transRes.getXmlData());
		}
	}
	
	private void signXml() throws Exception {
		String xmlData = "<Channel>"+channelName+"</Channel>\n"
	            + "<User>"+customerUser+"</User>\n"
	            + "<ID>01009090</ID>\n"
	            + "<FileType>xml</FileType>\n"
	            + "<MetaData>\n"
	            + "  <ExternalStorage>P2P</ExternalStorage>"
	            + "  <Method>SynchronousSign</Method>\n"
	            + "</MetaData>\n"
	            + "<WorkerName>MultiSigner</WorkerName>";

		// prepare file data
		byte[] fileToSign = IOUtils.toByteArray(new FileInputStream(FILE_SRC_XML));

		// prepare cagCredential
		String timeStamp = String.valueOf(System.currentTimeMillis());
		String dataToSign = user + passwd + signature + timeStamp;
		String pkcs1Sig = getPKCS1Signature(dataToSign, p12File, p12Pass);

		CagCredential credential = new CagCredential();
		credential.setUsername(user);
		credential.setPassword(passwd);
		credential.setSignature(signature);
		credential.setTimestamp(timeStamp);
		credential.setPkcs1Signature(pkcs1Sig);

		TransactionInfo transReq = new TransactionInfo();
		transReq.setXmlData(xmlData);
		transReq.setFileData(fileToSign);
		transReq.setCredentialData(credential);

		TransactionInfo transRes = getWS().processData(transReq);

		int responseCode = Integer.parseInt(getContent("ResponseCode",
				transRes.getXmlData()));
		if (responseCode == 0) {
			System.out.println("sign success");
			System.out.println("Saved file in " + FILE_DST_XML);
			System.out.println(transRes.getXmlData());
			IOUtils.write(transRes.getFileData(),
					new FileOutputStream(FILE_DST_DOC));
		} else {
			System.out.println("sign error: " + transRes.getXmlData());
		}
	}
	
	public void verifyXml() throws Exception {

		String xmlData = "<Channel>" + channelName + "</Channel>\n" + "<User>"
				+ customerUser + "</User>\n" + "<ID>01009090</ID>\n"
				+ "<MetaData>\n"
				+ "  <ExternalStorage>P2P</ExternalStorage>\n"
				+ "  <SignatureMethod>SPKI</SignatureMethod>\n"
				+ "</MetaData>\n" + "<WorkerName>MultiValidator</WorkerName>";

		// prepare file data
		byte[] fileToSign = IOUtils.toByteArray(new FileInputStream(FILE_DST_XML));

		// prepare cagCredential
		String timeStamp = String.valueOf(System.currentTimeMillis());
		String pkcs1Sig = getPKCS1Signature(user + passwd + signature
				+ timeStamp, p12File, p12Pass);

		CagCredential credential = new CagCredential();
		credential.setUsername(user);
		credential.setPassword(passwd);
		credential.setSignature(signature);
		credential.setTimestamp(timeStamp);
		credential.setPkcs1Signature(pkcs1Sig);

		TransactionInfo transReq = new TransactionInfo();
		transReq.setXmlData(xmlData);
		transReq.setFileData(fileToSign);
		transReq.setCredentialData(credential);

		TransactionInfo transRes = getWS().processData(transReq);
		int responseCode = Integer.parseInt(getContent("ResponseCode",
				transRes.getXmlData()));
		if (responseCode == 0) {
			System.out.println("verify success");
			System.out.println(transRes.getXmlData());
		} else {
			System.out.println("error: " + transRes.getXmlData());
		}
	}

	private ClientWS getWS() throws Exception {

		SSLUtilities.trustAllHostnames();
		SSLUtilities.trustAllHttpsCertificates();

		ClientWSService service = new ClientWSService(new URL(cagWSurl),
				new QName("http://clientws.signserver.org/", "ClientWSService"));
		return service.getClientWSPort();
	}

	private static void signOffice(ClientWS ws, String src, String des)
			throws Exception {

	}

	public String getContent(String tag, String xmlData) {
		try {
			String startTag = "<" + tag + ">";

			int hasTag = xmlData.indexOf(startTag);
			if (hasTag != -1) {
				String endTag = "</" + startTag.substring(1);
				int indexStart = xmlData.indexOf(startTag) + startTag.length();
				int indexEnd = xmlData.indexOf(endTag);
				return xmlData.substring(indexStart, indexEnd);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}

	private static String getPKCS1Signature(String data, String p12File,
			String p12Pass) throws FileNotFoundException, KeyStoreException,
			IOException, NoSuchAlgorithmException, CertificateException,
			UnrecoverableKeyException, SignatureException, InvalidKeyException {
		Security.addProvider(new BouncyCastleProvider());
		KeyStore keystore = KeyStore.getInstance("PKCS12");
		InputStream is = new FileInputStream(p12File);
		keystore.load(is, p12Pass.toCharArray());

		Enumeration<String> e = keystore.aliases();
		String aliasName = "";
		while (e.hasMoreElements()) {
			aliasName = e.nextElement();
		}
		PrivateKey key = (PrivateKey) keystore.getKey(aliasName,
				p12Pass.toCharArray());

		Signature sig = Signature.getInstance("SHA1withRSA");
		sig.initSign(key);
		sig.update(data.getBytes());
		return DatatypeConverter.printBase64Binary(sig.sign());
	}
}
