﻿using CAG360;
using CAG360.ClientWS;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ClientDemo
{
    class Program
    {
        private static string P12Path = "F:\\Tomica\\svn-project\\CAG360\\Files\\keystore\\trustedhub.p12";
        private static string P12Key = "12345678";
        private static string ServerUrl = "https://mobile-id.vn:9084/TRUSTEDHUB/";
        

        private static string username = "trustedhub";
        private static string password = "12345678";
        private static string signature = "tLA66gWm5qP0sCQp2BtUjhkhjVDRe99UkLHbkTdsjI2lx31T/Z2B2dp4cOsPATGrj6mHcFT4gFKSM1w9hbD+u2ekpYCNcgR8ttuWPNNmn8dHdVPHjDTiQSUogWMmkzjfIX/4oSJG92LeTx4hJ9kat/UILrV7mSvXBoZ8sxR1+g3jXTwU2MJpFrYnDmDZeVoQXSa101jvKFXShtv+o5Zk2S966vrG9X1RdJV9gQ8LTW71MXQgjh5lLNyZlMgJ3Mw6oVAwY1GR+23QoBaZsd9NDtCI7LLyU//3G/xEsaBwKcwZBKvaHcuy4bCPD22Dh0K38+bvEcL0rEqnKGhZIcuS8A==";

        private static string channelName = "TRUSTEDHUB";
        private static string customerUser = "105442939";

        string file_source_pdf = "E:\\File\\FileToSign\\ok.pdf";
        string file_destination_pdf = "E:\\File\\FileToSign\\ok_signed.pdf";

        string file_source_office = "E:\\File\\FileToSign\\ok.doc";
        string file_destination_office = "E:\\File\\FileToSign\\ok_signed.doc";


        public static void Main(string[] args)
        {
            ClientWSService service = new ClientWSService(ServerUrl);

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                    | SecurityProtocolType.Tls11
                    | SecurityProtocolType.Tls12
                    | SecurityProtocolType.Ssl3;
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.ServerCertificateValidationCallback += new RemoteCertificateValidationCallback(AlwaysGoodCert);
            Program demo = new Program();

            //demo.dcSignerSignRequest(service);
            //demo.dcSignerSignResponse(service);
            demo.multiSignerSynchronousSign(service);
            //demo.signerAPSignPdf(service);
            //demo.signerAPSignOffice(service);
            //demo.signOffice(service);
            //demo.signPdf(service);
            //demo.signXml(service);
        }

        private void multiSignerSynchronousSign(ClientWSService service)
        {
            try
            {
                string requestXML = "<Channel>" + channelName + "</Channel>\n"
                            + "<User>" + customerUser + "</User>\n"
                            + "<ID>01009090</ID>\n"
                            + "<MetaData>\n"
                            + "  <Method>SynchronousSign</Method>\n"
                            + "  <ExternalStorage>DMS</ExternalStorage>\n"
                            + "  <FileId>{8253F999-5923-CD35-8433-57BC5F100000}</FileId>\n"
                            + "  <PageNo>1</PageNo>\n"
                            + "  <Coordinate>50,500,550,680</Coordinate>\n"
                            + "  <SignReason>Ký lần 2, sếp cho ý kiến</SignReason>\n"
                            + " <CitizenID>citizenId</CitizenID>\n"
                            + " <ApplicationID>appId</ApplicationID>\n"
                            + " <UserHandle>userId</UserHandle>"
                            + "</MetaData>\n"
                            + "<WorkerName>MultiSigner</WorkerName>";

                string timestamp = CurrentTimeMillis().ToString();

                string data = username + password + signature + timestamp;
                string pkcs1Signature = getPKCS1Signature(data, P12Path, P12Key);
                cagCredential cag = new cagCredential();
                cag.username = username;
                cag.password = password;
                cag.signature = signature;
                cag.timestamp = timestamp;
                cag.pkcs1Signature = pkcs1Signature;

                //Get file data as byte array
                FileStream fs = new FileStream(file_source_pdf, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                long numBytes = new FileInfo(file_source_pdf).Length;
                byte[] buff = br.ReadBytes((int)numBytes);

                // Prepare request to send to server
                transactionInfo request = new transactionInfo();
                request.credentialData = cag;
                request.fileData = buff; //need to do
                request.xmlData = requestXML;

                processData dataToSend = new processData();
                dataToSend.transInfo = request;

                processDataResponse response = service.processData(dataToSend);

                // Write signed byte array to file
                int responseCode = Int32.Parse(getContent("ResponseCode", response.@return.xmlData));
                if (responseCode == 113)
                {
                    Debug.WriteLine("success!");
                    Debug.WriteLine(response.@return.xmlData);
                }
                else
                {
                    Debug.WriteLine("error: " + response.@return.xmlData);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
            Console.ReadLine();
        }

        private void dcSignerSignRequest(ClientWSService service)
        {
            try
            {
                string requestXML = "<Channel>" + channelName + "</Channel>\n"
                            + "<User>" + customerUser + "</User>\n"
                            + "<ID>01009090</ID>\n"
                            + "<FileType>pdf</FileType>\n"
                            + "<MetaData>\n"
                            + " <ExternalStorage>DMS</ExternalStorage>\n"
                            + " <FileId>{8253F999-5923-CD35-8433-57BC5F100000}</FileId>\n"
                            + " <Method>SignRequest</Method>\n"
                            + " <VisibleSignature>True</VisibleSignature>\n"
                            + " <Coordinate>0,0,200,60</Coordinate>\n"
                            + " <PageNo>1</PageNo>\n"
                            + " <SignReason>Ký duyệt</SignReason>\n"
                            + " <VisualStatus>True</VisualStatus>\n"
                            + " <SignatureImage>/9j/4AAQSkZJRgABAQEAYABgAAD/4QB4RXhpZgAATU0AKgAAAAgABgExAAIAAAARAAAAVgMBAAUAAAABAAAAaAMDAAEAAAABAAAAAFEQAAEAAAABAQAAAFERAAQAAAABAAAOxFESAAQAAAABAAAOxAAAAABBZG9iZSBJbWFnZVJlYWR5AAAAAYagAACxj//bAEMAAgEBAgEBAgICAgICAgIDBQMDAwMDBgQEAwUHBgcHBwYHBwgJCwkICAoIBwcKDQoKCwwMDAwHCQ4PDQwOCwwMDP/bAEMBAgICAwMDBgMDBgwIBwgMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDP/AABEIACgAfgMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/AP38oor53/aG/a28K+EfHkOmR+NtIhS0t54dShieWf7K7KQBIYgyqxPygNyDnp1pqnVlpShKbutIpt6tK+nRX1OXFY7DYWHPiakYLWzk1FN2va7a1PXPBHx18G/EnxJqGj6D4l0fVtU0vP2q2trlZJIwDtJwPvAEgEjIBIB611NxcR2lvJLK6xxxqXd2OFUDkkn2r8l/+CRc7D9tPTQrttks7sMAcBh5Ln+gr9E/23/HE/gX9mDxVJZLJJqWrW40iyjiOJJJbphANn+0Fdm/4DX0ebZFHC5hDBUpN83Lq/N2/wCCfE8LcaTzLI62b4mmo+zc7pX1UYqXXrZ29fWx6F4N8daP8QfCttrmi6hbajpN4rNDdRN+7cKxVuT0wysCD0IIqr4d+K/hvxX4BXxVp+uabceHGSST+0vOC24VGZHJdsABWVgc9CK+O7+HWP2Y9P8AEX7Pujy3sl147ezHhW8ZXmEEN2vlaizsMBFjMcrAA7hvLVg+JvDcPwp8Da18M79r+78GfD/4l6dqGsREFsaDeI0sYkI5dBIAW287mXuK2jw9Sm/cm7Npx01cHZXt/NeSil/MpLoctTjrEUopVaKUoxlGpq0o1ld8t9bQUYSm27vkcGtz60039s74V6tq0dlB468Pm4mcRpvuPLRmJwAHYBeTwOea1viT+0r4E+EGvx6X4l8TadpGoTW63SQTFt7RMzKHwAeCyMP+AmvM/jT41+ANz8D9aW6vvhzdaadOkMEOny2jXBOwmPyFj+YSA4KlcEEZ4xmvC/AUl94e+MHg+PxBfeE9L8QD4P26Wsvi1R9jjf8AtUmNJFdlbzBb8YBDAg56EVOHyjDVY+1tOKV1Z2u9L3T5dl9r3Xa67mmO4px+FqLD81KpKSTUop2jd2tKPPvL7D51e0tND6++Hv7TPgH4ray2neH/ABVpGp6gsbS/Zo5dszIv3mVWALAd8ZxV3wr8d/B/jhtDGk+ILC//AOEljnl0vymJ+2rAzLKU4/hKsDn+6a+UtAv5bv8AbI+FU2rat8J9euEOpRWi+B1EUts72xG+5BLlowofADLj5jyAQea/ZA8VaX4PtP2ab7V9SsNLsk0fxIrXF5cJBEpNzKACzEDk8VpVyCjyOdNy+G6W/wBmq+yvrBdFu/U58Nxti/aqlWjD4+VuzWnPh1e3NJLStL7T2T01R9z+PfiDovwu8LXGt+INQt9K0m1KLNczkhELsEUHHqzAfU1wumftrfCvWdRgtLXxrpM1xdSLFEg8zLsTgD7vrXm//BQ74n+GfHP7HfiqLRvEOg6w1vc6bJOllfxXBiT+0LcbmCscLzjJ4qSw8RzT/FmD7D4s/Zzfw62qKYLeKEHVDbeb8qKwm2+fs4BC43c4xxXHhcrovDe1rqXNeS3tsov+WWr5vLY9bMuIsVHMPq2DlDkUYO7XM25Smnr7SCSXJ2buz6Wrz/Xv2qvh34Y0Ox1K/wDFml21jqUs0FrMxbbO8JCygYGflLKD9RWxfReND8SbVra48Lr4P2f6RFLBOdSLbW+44fywN23qp4z3xXxP8M77SdN1/wCAk2vTabb6PH4m8W/aZNQZFtlBjYLvMny/eK4z3xjnFZ5bldKvGU6jbtraO/wzlbVPX3UvmbcQcRYjB1IUqEVHm0vNO38SjC+kleNqje626H2V8Ov2kPAnxa1VrDw74q0fVL9VL/Zo5tszKOrBGwzAdyAQK7avlH9p7Vfh94o8Y/DaH4f3Hhy+8fp4os3s38PyQvNDbAsZzM0P/LDaMsGPIBOCA1fV1cuYYSnSjCpTTSlfSW6s7X2V0+jstU10PSyTNK2JqVsPXcJOm4+9C/K+ZXtZt2kuqu9HF9bLwH/gph8Y9U+C37JutX2izyWmpapNFpcVzGSr26ybi7KRyGKIygjkFsjkV4f/AME+NEg1H9mfwu0mn3Vyt9e6p9reMgQy5jjX96MfN8oxyRleOelfQ37fvwBvv2jv2Zda0HSVEmsW7pqFjETjz5I85j7DLIzqMkDcVzxmvkH9kz4gab4U+A+n6Dr9zHo154ZvNSW/gnvFtbiDci4BjcgjOMcDJ5XkjFcvEUI1OFvZ0Vef1ig2kru3tIWdlGTt8tH1W54uHdWlxzGtiny0fqtVRbaUb2fMk20r21et2rbpHkH/AATE8St4W/aysbtVUyLY3m0vyqnyHGSByevQV+qPh/QT8UdGtbzxTp2nXtvb3UV/psE1sG+zyx52T/NnD5JI9M+9fAP/AASR/ZC1jxJ8RZPH+tWNxZ+G7G3eGyMy7f7Slfg7P70arnLDgkgDPzY/TJVCKABgDgAdq+m4zxMZ5nek9YxSduju3+p4/hLl9Slw9bEQ0qTlJJreNopOz6Np27rU5DxulnaeM9L1RvBeoa/qmlwyfY9RtorVnshL8siK0sqMpZQM4GCD16isp9UtpNbvtSb4Z681/qduLS8naDTzJdQjpG5+0fMo9DkV6JXkvxb/AGqLH4U/GTR/DdxDDJZTWjXOp3O9vMszIJPsqqMbT5jwyKdxXBaPGd1eBhfa1X7OnG7SfV7LXv36d/M+4zH6vhl7fEVOVOS+zH4n7qfwt7aN9I3u7IztI+E/gXQNZh1Cy+Bf2W+t382KaPStLVon/vL+/wDlPuOlX/HvhHwz8UtYj1DxJ8Hb/XL6GEW6XF9ZadNIkYLMEDNcE7QWY49SaqD9tPSJLRY18P69Fq10g+wWM3kBr2QwwXAQOshUFbe5imbJ+VA/UqRVLw5+2vDqf2eGbwzqlxqF19jP2ezltytt9qS0ESNI8qhyZrtFyowF5IGDXoezxzl7Tld115ne3k+bb8Dw/bZMoewU1yt3a9nG113XJut7PVLXY2PA3hHwz8MtSkvPDvwbvNFvJo/KeezsNNhlZO67lnzg+mcVT1H4Y+C9X0PTNMuvgjPcafoqyJYW0mnaa0Vmsjb3Ea+fhQzcnHU1rfCj9rXw78X/ABPHpmnWmr27S2wmE9zAqwrJ5cMhhLBjhwLiMDsx3YJwCcfxx+2TpvgH4y614fu7Pz9L0bTyxngbNxPfqizNaqrYj5gdWBLg7gwwMZqIxxrqtcr57X3le219/O3zZpKeURwyk6kfZN8q9yFrvVq3L15U/Oy8hLH4UeB9M0u+srf4HSQ2eposV3Cmm6aEuVV1kVXHn4YB0RhnuoPaodP+DHgHSb+G6tfgSbe5t3EkUsemaYrRsDkEHz+CDWhdftoeH9Le4hvtJ16zvLHzpLuBo4mNvb28s8V1cllkKmKB4HDsDn5kwDurJi/bq0nVdUtJtO0PVrnRI4Lh9TuHEcc1i0clqv3C/wAwVbpGYDLYdMA5ONIrMHeylr/elrp/i12t+BzzlkcUrzhpsvZwute3Jdau77Xuek/8LO1D/oR/F3/kl/8AJNcXrXgHwn4j0e10+/8Agvd3ljYyyzW8E1hprxwPKQZGUG4wCxAJI64qiP27vDb2UlxHofiaWCOGW8MiwRqv2VAn7/LSDgl1XaPmBPIA5r1L4afEG2+J/hCHWLW2vLOOSWWFobqPZJG8UjRuPQjcpwRwRg1yyp4jCrncOXXu1rr2fqepTrYHMZexjWVR22cYvS67x2vb5ryMv4WfBvwf8Pov7Q8P+C9H8LXl5GBMIbGCG4Vf7jtHn8gxFdlRRXm1as6kuebbfm7/AJnv4fD0qFNUqUVFLokkvuVkFYPiH4XeGfF2qR32reHdB1S9hx5dxd2EU0seOmGZSR+FFFTGcou8XYupShUXLUSa81c3Io1hjVEVVRQFVVGAAOwp1FFSaBWfqHhLSdWivEutL0+6TUChulltkcXJTGzeCPm24GM5xgYoopxk1qiZQjJWkrmbc/CrQbrxVpusNp8K3ekrJ9lVBsijaSJYWk2D5S/kqIwxBIT5RxVrTvh54f0hUW00PR7VY9hQQ2UabdhVkxheNrIhHoVUjoKKKt1qjVm2YxwtGLbUFdu70W9kr/ckvkivc/CfwzdyK7aBpCyRmAq8dqkbjyHSSEblAOEaOMgdBsX0q5e+CdF1K3aG40jS7iGS5N4ySWqMrTkYMpBH38HG7r70UUe2m92/vKWGoq9oLXyRRPwp0F/FVzrEmnwzXV1Yyac6SDdCIJZPNmUR/d/evhnOMuVGc1dHgXRFV1Gj6UFk3bh9kj+bds3Z47+XHn18tf7owUUOtN7tijhaK2gtfJEVt8OfD1mtyIdB0aIXnmm4CWUa+f5oAk3/AC/NvAAbPXAzmtDR9Fs/D2mxWen2ttY2cAIjgt4hHHGCcnCqABySfxooqZVJPRsuFGnB3jFL0RaoooqTQ//Z</SignatureImage>\n"
                            + "</MetaData>\n"
                            + "<WorkerName>DCSigner</WorkerName>";

                string timestamp = CurrentTimeMillis().ToString();

                string data = username + password + signature + timestamp;
                string pkcs1Signature = getPKCS1Signature(data, P12Path, P12Key);
                cagCredential cag = new cagCredential();
                cag.username = username;
                cag.password = password;
                cag.signature = signature;
                cag.timestamp = timestamp;
                cag.pkcs1Signature = pkcs1Signature;

                //Get file data as byte array
                FileStream fs = new FileStream(file_source_pdf, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                long numBytes = new FileInfo(file_source_pdf).Length;
                byte[] buff = br.ReadBytes((int)numBytes);

                // Prepare request to send to server
                transactionInfo request = new transactionInfo();
                request.credentialData = cag;
                request.fileData = buff; //need to do
                request.xmlData = requestXML;

                processData dataToSend = new processData();
                dataToSend.transInfo = request;

                processDataResponse response = service.processData(dataToSend);

                // Write signed byte array to file
                int responseCode = Int32.Parse(getContent("ResponseCode", response.@return.xmlData));
                if (responseCode == 113)
                {
                    Debug.WriteLine("success! request accepted");
                    Debug.WriteLine(response.@return.xmlData);
                    Debug.WriteLine("BillCode: " + getContent("BillCode", response.@return.xmlData));
                    Debug.WriteLine("DataToBeSigned: " + getContent("DataToBeSigned", response.@return.xmlData));
                }
                else
                {
                    Debug.WriteLine("error: " + response.@return.xmlData);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
            Console.ReadLine();
        }

        private void dcSignerSignResponse(ClientWSService service)
        {
            try
            {
                string billCode = "TRUSTEDHUB-105442939-20170731104618-1148";
                string s = "eLX+BcYG7JIglFjkZWaxMcqzl2TuLAJXvm9iEDn5mhvz/AhNJWgZTCsv9oFxAZJOrDMiC2PnLwEPCKNfh4CFpsd3O8g39+lzhpHUUftxO0we0sQQBpxbTp5mD1+sYWa6oXqe6RejTc4DA2sR5W1da3juHVuJ1hfWJn1jPLyndAPXwr5upWjgTGxd67LRkFF90a0jhXZKKFLUF3/+b5ldJ22YcyH9bPS0oCLXMRiiJzujVr+P+3kBFK5jjp29JxMiTrUze/Jbc0scdTFjVxS+G584ZJbnm2igeTpQIDENYck0YvoMtOh9odbUavllUPEViXdfOJb5XvScHzRxMMohiw==";

                string requestXML = "<Channel>" + channelName + "</Channel>\n"
                            + "<User>" + customerUser + "</User>\n"
                            + "<ID>01009090</ID>\n"
                            + "<MetaData>\n"
                            + " <ExternalStorage>DMS</ExternalStorage>\n"
                            + " <Method>SignResponse</Method>\n"
                            + " <Signature>" + s + "</Signature>\n"
                            + " <BillCode>" + billCode + "</BillCode>\n"
                            + " <CitizenID>citizenId</CitizenID>\n"
                            + " <ApplicationID>appId</ApplicationID>\n"
                            + " <UserHandle>userId</UserHandle>\n"
                            + "</MetaData>\n"
                            + "<WorkerName>DCSigner</WorkerName>";

                string timestamp = CurrentTimeMillis().ToString();

                string data = username + password + signature + timestamp;
                string pkcs1Signature = getPKCS1Signature(data, P12Path, P12Key);
                cagCredential cag = new cagCredential();
                cag.username = username;
                cag.password = password;
                cag.signature = signature;
                cag.timestamp = timestamp;
                cag.pkcs1Signature = pkcs1Signature;

                //Get file data as byte array
                FileStream fs = new FileStream(file_source_pdf, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                long numBytes = new FileInfo(file_source_pdf).Length;
                byte[] buff = br.ReadBytes((int)numBytes);

                // Prepare request to send to server
                transactionInfo request = new transactionInfo();
                request.credentialData = cag;
                request.fileData = buff; //need to do
                request.xmlData = requestXML;

                processData dataToSend = new processData();
                dataToSend.transInfo = request;

                processDataResponse response = service.processData(dataToSend);

                // Write signed byte array to file
                int responseCode = Int32.Parse(getContent("ResponseCode", response.@return.xmlData));
                if (responseCode == 0)
                {
                    Debug.WriteLine("success!");
                    Debug.WriteLine(response.@return.xmlData);
                }
                else
                {
                    Debug.WriteLine("error: " + response.@return.xmlData);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
            Console.ReadLine();
        }

        private void signerAPSignPdf(ClientWSService service)
        {
            try
            {

                string requestXML = "<Channel>" + channelName + "</Channel>\n"
                + "<User>" + customerUser + "</User>\n"
                + "<ID>01009090</ID>\n"
                + "<FileType>pdf</FileType>\n"
                + "<MetaData>\n"
                + "  <ExternalStorage>P2P</ExternalStorage>\n"
                + "  <Method>SignFileRequest</Method>\n"
                + "  <VisibleSignature>True</VisibleSignature>\n"
                + "  <Coordinate>0,0,200,60</Coordinate>\n"
                + "  <PageNo>1</PageNo>\n"
                + "  <SignReason>Ký duyệt</SignReason>\n"
                + "  <VisualStatus>True</VisualStatus>\n"
                + "  <SignatureImage>/9j/4AAQSkZJRgABAQEAYABgAAD/4QB4RXhpZgAATU0AKgAAAAgABgExAAIAAAARAAAAVgMBAAUAAAABAAAAaAMDAAEAAAABAAAAAFEQAAEAAAABAQAAAFERAAQAAAABAAAOxFESAAQAAAABAAAOxAAAAABBZG9iZSBJbWFnZVJlYWR5AAAAAYagAACxj//bAEMAAgEBAgEBAgICAgICAgIDBQMDAwMDBgQEAwUHBgcHBwYHBwgJCwkICAoIBwcKDQoKCwwMDAwHCQ4PDQwOCwwMDP/bAEMBAgICAwMDBgMDBgwIBwgMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDP/AABEIACgAfgMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/AP38oor53/aG/a28K+EfHkOmR+NtIhS0t54dShieWf7K7KQBIYgyqxPygNyDnp1pqnVlpShKbutIpt6tK+nRX1OXFY7DYWHPiakYLWzk1FN2va7a1PXPBHx18G/EnxJqGj6D4l0fVtU0vP2q2trlZJIwDtJwPvAEgEjIBIB611NxcR2lvJLK6xxxqXd2OFUDkkn2r8l/+CRc7D9tPTQrttks7sMAcBh5Ln+gr9E/23/HE/gX9mDxVJZLJJqWrW40iyjiOJJJbphANn+0Fdm/4DX0ebZFHC5hDBUpN83Lq/N2/wCCfE8LcaTzLI62b4mmo+zc7pX1UYqXXrZ29fWx6F4N8daP8QfCttrmi6hbajpN4rNDdRN+7cKxVuT0wysCD0IIqr4d+K/hvxX4BXxVp+uabceHGSST+0vOC24VGZHJdsABWVgc9CK+O7+HWP2Y9P8AEX7Pujy3sl147ezHhW8ZXmEEN2vlaizsMBFjMcrAA7hvLVg+JvDcPwp8Da18M79r+78GfD/4l6dqGsREFsaDeI0sYkI5dBIAW287mXuK2jw9Sm/cm7Npx01cHZXt/NeSil/MpLoctTjrEUopVaKUoxlGpq0o1ld8t9bQUYSm27vkcGtz60039s74V6tq0dlB468Pm4mcRpvuPLRmJwAHYBeTwOea1viT+0r4E+EGvx6X4l8TadpGoTW63SQTFt7RMzKHwAeCyMP+AmvM/jT41+ANz8D9aW6vvhzdaadOkMEOny2jXBOwmPyFj+YSA4KlcEEZ4xmvC/AUl94e+MHg+PxBfeE9L8QD4P26Wsvi1R9jjf8AtUmNJFdlbzBb8YBDAg56EVOHyjDVY+1tOKV1Z2u9L3T5dl9r3Xa67mmO4px+FqLD81KpKSTUop2jd2tKPPvL7D51e0tND6++Hv7TPgH4ray2neH/ABVpGp6gsbS/Zo5dszIv3mVWALAd8ZxV3wr8d/B/jhtDGk+ILC//AOEljnl0vymJ+2rAzLKU4/hKsDn+6a+UtAv5bv8AbI+FU2rat8J9euEOpRWi+B1EUts72xG+5BLlowofADLj5jyAQea/ZA8VaX4PtP2ab7V9SsNLsk0fxIrXF5cJBEpNzKACzEDk8VpVyCjyOdNy+G6W/wBmq+yvrBdFu/U58Nxti/aqlWjD4+VuzWnPh1e3NJLStL7T2T01R9z+PfiDovwu8LXGt+INQt9K0m1KLNczkhELsEUHHqzAfU1wumftrfCvWdRgtLXxrpM1xdSLFEg8zLsTgD7vrXm//BQ74n+GfHP7HfiqLRvEOg6w1vc6bJOllfxXBiT+0LcbmCscLzjJ4qSw8RzT/FmD7D4s/Zzfw62qKYLeKEHVDbeb8qKwm2+fs4BC43c4xxXHhcrovDe1rqXNeS3tsov+WWr5vLY9bMuIsVHMPq2DlDkUYO7XM25Smnr7SCSXJ2buz6Wrz/Xv2qvh34Y0Ox1K/wDFml21jqUs0FrMxbbO8JCygYGflLKD9RWxfReND8SbVra48Lr4P2f6RFLBOdSLbW+44fywN23qp4z3xXxP8M77SdN1/wCAk2vTabb6PH4m8W/aZNQZFtlBjYLvMny/eK4z3xjnFZ5bldKvGU6jbtraO/wzlbVPX3UvmbcQcRYjB1IUqEVHm0vNO38SjC+kleNqje626H2V8Ov2kPAnxa1VrDw74q0fVL9VL/Zo5tszKOrBGwzAdyAQK7avlH9p7Vfh94o8Y/DaH4f3Hhy+8fp4os3s38PyQvNDbAsZzM0P/LDaMsGPIBOCA1fV1cuYYSnSjCpTTSlfSW6s7X2V0+jstU10PSyTNK2JqVsPXcJOm4+9C/K+ZXtZt2kuqu9HF9bLwH/gph8Y9U+C37JutX2izyWmpapNFpcVzGSr26ybi7KRyGKIygjkFsjkV4f/AME+NEg1H9mfwu0mn3Vyt9e6p9reMgQy5jjX96MfN8oxyRleOelfQ37fvwBvv2jv2Zda0HSVEmsW7pqFjETjz5I85j7DLIzqMkDcVzxmvkH9kz4gab4U+A+n6Dr9zHo154ZvNSW/gnvFtbiDci4BjcgjOMcDJ5XkjFcvEUI1OFvZ0Vef1ig2kru3tIWdlGTt8tH1W54uHdWlxzGtiny0fqtVRbaUb2fMk20r21et2rbpHkH/AATE8St4W/aysbtVUyLY3m0vyqnyHGSByevQV+qPh/QT8UdGtbzxTp2nXtvb3UV/psE1sG+zyx52T/NnD5JI9M+9fAP/AASR/ZC1jxJ8RZPH+tWNxZ+G7G3eGyMy7f7Slfg7P70arnLDgkgDPzY/TJVCKABgDgAdq+m4zxMZ5nek9YxSduju3+p4/hLl9Slw9bEQ0qTlJJreNopOz6Np27rU5DxulnaeM9L1RvBeoa/qmlwyfY9RtorVnshL8siK0sqMpZQM4GCD16isp9UtpNbvtSb4Z681/qduLS8naDTzJdQjpG5+0fMo9DkV6JXkvxb/AGqLH4U/GTR/DdxDDJZTWjXOp3O9vMszIJPsqqMbT5jwyKdxXBaPGd1eBhfa1X7OnG7SfV7LXv36d/M+4zH6vhl7fEVOVOS+zH4n7qfwt7aN9I3u7IztI+E/gXQNZh1Cy+Bf2W+t382KaPStLVon/vL+/wDlPuOlX/HvhHwz8UtYj1DxJ8Hb/XL6GEW6XF9ZadNIkYLMEDNcE7QWY49SaqD9tPSJLRY18P69Fq10g+wWM3kBr2QwwXAQOshUFbe5imbJ+VA/UqRVLw5+2vDqf2eGbwzqlxqF19jP2ezltytt9qS0ESNI8qhyZrtFyowF5IGDXoezxzl7Tld115ne3k+bb8Dw/bZMoewU1yt3a9nG113XJut7PVLXY2PA3hHwz8MtSkvPDvwbvNFvJo/KeezsNNhlZO67lnzg+mcVT1H4Y+C9X0PTNMuvgjPcafoqyJYW0mnaa0Vmsjb3Ea+fhQzcnHU1rfCj9rXw78X/ABPHpmnWmr27S2wmE9zAqwrJ5cMhhLBjhwLiMDsx3YJwCcfxx+2TpvgH4y614fu7Pz9L0bTyxngbNxPfqizNaqrYj5gdWBLg7gwwMZqIxxrqtcr57X3le219/O3zZpKeURwyk6kfZN8q9yFrvVq3L15U/Oy8hLH4UeB9M0u+srf4HSQ2eposV3Cmm6aEuVV1kVXHn4YB0RhnuoPaodP+DHgHSb+G6tfgSbe5t3EkUsemaYrRsDkEHz+CDWhdftoeH9Le4hvtJ16zvLHzpLuBo4mNvb28s8V1cllkKmKB4HDsDn5kwDurJi/bq0nVdUtJtO0PVrnRI4Lh9TuHEcc1i0clqv3C/wAwVbpGYDLYdMA5ONIrMHeylr/elrp/i12t+BzzlkcUrzhpsvZwute3Jdau77Xuek/8LO1D/oR/F3/kl/8AJNcXrXgHwn4j0e10+/8Agvd3ljYyyzW8E1hprxwPKQZGUG4wCxAJI64qiP27vDb2UlxHofiaWCOGW8MiwRqv2VAn7/LSDgl1XaPmBPIA5r1L4afEG2+J/hCHWLW2vLOOSWWFobqPZJG8UjRuPQjcpwRwRg1yyp4jCrncOXXu1rr2fqepTrYHMZexjWVR22cYvS67x2vb5ryMv4WfBvwf8Pov7Q8P+C9H8LXl5GBMIbGCG4Vf7jtHn8gxFdlRRXm1as6kuebbfm7/AJnv4fD0qFNUqUVFLokkvuVkFYPiH4XeGfF2qR32reHdB1S9hx5dxd2EU0seOmGZSR+FFFTGcou8XYupShUXLUSa81c3Io1hjVEVVRQFVVGAAOwp1FFSaBWfqHhLSdWivEutL0+6TUChulltkcXJTGzeCPm24GM5xgYoopxk1qiZQjJWkrmbc/CrQbrxVpusNp8K3ekrJ9lVBsijaSJYWk2D5S/kqIwxBIT5RxVrTvh54f0hUW00PR7VY9hQQ2UabdhVkxheNrIhHoVUjoKKKt1qjVm2YxwtGLbUFdu70W9kr/ckvkivc/CfwzdyK7aBpCyRmAq8dqkbjyHSSEblAOEaOMgdBsX0q5e+CdF1K3aG40jS7iGS5N4ySWqMrTkYMpBH38HG7r70UUe2m92/vKWGoq9oLXyRRPwp0F/FVzrEmnwzXV1Yyac6SDdCIJZPNmUR/d/evhnOMuVGc1dHgXRFV1Gj6UFk3bh9kj+bds3Z47+XHn18tf7owUUOtN7tijhaK2gtfJEVt8OfD1mtyIdB0aIXnmm4CWUa+f5oAk3/AC/NvAAbPXAzmtDR9Fs/D2mxWen2ttY2cAIjgt4hHHGCcnCqABySfxooqZVJPRsuFGnB3jFL0RaoooqTQ//Z</SignatureImage>\n"
                + "  <MessageMode>Async</MessageMode>\n"
                + "  <DisplayMessage>Ma giao dich {transcode}. Vui long xac nhan</DisplayMessage>\n"
                + "</MetaData>\n"
                + "<WorkerName>SignerAP</WorkerName>";

                string timestamp = CurrentTimeMillis().ToString();

                string data = username + password + signature + timestamp;
                string pkcs1Signature = getPKCS1Signature(data, P12Path, P12Key);
                cagCredential cag = new cagCredential();
                cag.username = username;
                cag.password = password;
                cag.signature = signature;
                cag.timestamp = timestamp;
                cag.pkcs1Signature = pkcs1Signature;

                //Get file data as byte array
                FileStream fs = new FileStream(file_source_pdf, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                long numBytes = new FileInfo(file_source_pdf).Length;
                byte[] buff = br.ReadBytes((int)numBytes);

                // Prepare request to send to server
                transactionInfo request = new transactionInfo();
                request.credentialData = cag;
                request.fileData = buff; //need to do
                request.xmlData = requestXML;

                processData dataToSend = new processData();
                dataToSend.transInfo = request;

                processDataResponse response = service.processData(dataToSend);

                Debug.WriteLine(response.@return.xmlData);
                // Write signed byte array to file
                int responseCode = Int32.Parse(getContent("ResponseCode", response.@return.xmlData));
                if (responseCode == 0)
                {
                    File.WriteAllBytes(file_destination_pdf, response.@return.fileData);
                    Debug.WriteLine("immediately successfully sign!!!");
                }
                else
                {
                    if (responseCode == 113)
                    {
                        // request accepted   
                        string billCode = getContent("BillCode", response.@return.xmlData);

                        requestXML = "<Channel>" + channelName + "</Channel>\n"
                                + "<User>" + customerUser + "</User>\n"
                                + "<ID>01009090</ID>\n"
                                + "<MetaData>\n"
                                + "	<Method>SignFileResponse</Method>\n"
                                + "	<BillCode>" + billCode + "</BillCode>\n"
                                + "</MetaData>\n"
                                + "<WorkerName>SignerAP</WorkerName>";
                        while(true) {
				            // prepare cagCredential
				            timestamp = CurrentTimeMillis().ToString();
				            data = username + password + signature + timestamp;
                            pkcs1Signature = getPKCS1Signature(data, P12Path, P12Key);

				            cag = new cagCredential();
                            cag.username = username;
                            cag.password = password;
                            cag.signature = signature;
                            cag.timestamp = timestamp;
                            cag.pkcs1Signature = pkcs1Signature;

				            request = new transactionInfo();
                            request.credentialData = cag;
                            request.fileData = buff; //need to do
                            request.xmlData = requestXML;

                            dataToSend = new processData();
                            dataToSend.transInfo = request;

                            response = service.processData(dataToSend);
				            if(responseCode == 0) {
					            Debug.WriteLine("Sign OK. File saved!");
                                File.WriteAllBytes(file_destination_pdf, response.@return.fileData);
					            break;
				            } else if(responseCode == 116) {
					            // outstanding transaction.
					            Thread.Sleep(2000);
				            } else {
					            // error
                                Debug.WriteLine("error: " + response.@return.xmlData);
					            break;
				            }
			            }
                    }
                    else
                    { 
                        // error
                        Debug.WriteLine("error: "+response.@return.xmlData);
                    }
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
            Console.ReadLine();
        }

        private void signerAPSignOffice(ClientWSService service)
        {
            try
            {

                string requestXML = "<Channel>" + channelName + "</Channel>\n"
                + "<User>" + customerUser + "</User>\n"
                + "<ID>01009090</ID>\n"
                + "<FileType>doc</FileType>\n"
                + "<MetaData>\n"
                + "  <ExternalStorage>P2P</ExternalStorage>\n"
                + "  <Method>SignFileRequest</Method>\n"
                + "  <MessageMode>Async</MessageMode>\n"
                + "  <DisplayMessage>Ma giao dich {transcode}. Vui long xac nhan</DisplayMessage>\n"
                + "</MetaData>\n"
                + "<WorkerName>SignerAP</WorkerName>";

                string timestamp = CurrentTimeMillis().ToString();

                string data = username + password + signature + timestamp;
                string pkcs1Signature = getPKCS1Signature(data, P12Path, P12Key);
                cagCredential cag = new cagCredential();
                cag.username = username;
                cag.password = password;
                cag.signature = signature;
                cag.timestamp = timestamp;
                cag.pkcs1Signature = pkcs1Signature;

                //Get file data as byte array
                FileStream fs = new FileStream(file_source_office, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                long numBytes = new FileInfo(file_source_office).Length;
                byte[] buff = br.ReadBytes((int)numBytes);

                // Prepare request to send to server
                transactionInfo request = new transactionInfo();
                request.credentialData = cag;
                request.fileData = buff; //need to do
                request.xmlData = requestXML;

                processData dataToSend = new processData();
                dataToSend.transInfo = request;

                processDataResponse response = service.processData(dataToSend);

                Debug.WriteLine(response.@return.xmlData);
                // Write signed byte array to file
                int responseCode = Int32.Parse(getContent("ResponseCode", response.@return.xmlData));
                if (responseCode == 0)
                {
                    File.WriteAllBytes(file_destination_office, response.@return.fileData);
                    Debug.WriteLine("immediately successfully sign!!!");
                }
                else
                {
                    if (responseCode == 113)
                    {
                        // request accepted   
                        string billCode = getContent("BillCode", response.@return.xmlData);

                        requestXML = "<Channel>" + channelName + "</Channel>\n"
                                + "<User>" + customerUser + "</User>\n"
                                + "<ID>01009090</ID>\n"
                                + "<MetaData>\n"
                                + "	<Method>SignFileResponse</Method>\n"
                                + "	<BillCode>" + billCode + "</BillCode>\n"
                                + "</MetaData>\n"
                                + "<WorkerName>SignerAP</WorkerName>";
                        while (true)
                        {
                            // prepare cagCredential
                            timestamp = CurrentTimeMillis().ToString();
                            data = username + password + signature + timestamp;
                            pkcs1Signature = getPKCS1Signature(data, P12Path, P12Key);

                            cag = new cagCredential();
                            cag.username = username;
                            cag.password = password;
                            cag.signature = signature;
                            cag.timestamp = timestamp;
                            cag.pkcs1Signature = pkcs1Signature;

                            request = new transactionInfo();
                            request.credentialData = cag;
                            request.fileData = buff; //need to do
                            request.xmlData = requestXML;

                            dataToSend = new processData();
                            dataToSend.transInfo = request;

                            response = service.processData(dataToSend);
                            if (responseCode == 0)
                            {
                                Debug.WriteLine("Sign OK. File saved!");
                                File.WriteAllBytes(file_destination_office, response.@return.fileData);
                                break;
                            }
                            else if (responseCode == 116)
                            {
                                // outstanding transaction.
                                Thread.Sleep(2000);
                            }
                            else
                            {
                                // error
                                Debug.WriteLine("error: " + response.@return.xmlData);
                                break;
                            }
                        }
                    }
                    else
                    {
                        // error
                        Debug.WriteLine("error: " + response.@return.xmlData);
                    }
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
            Console.ReadLine();
        }

        public void register(ClientWSService service) {
		    try {
                string msisdn = "<so dien thoai>";

                string requestXML = "<Channel>"+channelName+"</Channel>\n"
	            + "<User>"+customerUser+"</User>\n"
	            + "<ID>01009090</ID>\n"
	            + "<WorkerName>AgreementHandler</WorkerName>\n"
	            + "<Action>REGISTRATION</Action>\n"
	            + "<Expiration>720</Expiration>\n"
	            + "<IsPKISim>True</IsPKISim>\n"
	            + "<PKISim>"+msisdn+"</PKISim>\n"
	            + "<PKISimVendor>VIETTEL</PKISimVendor>\n"
	            + "<DisplayMessage>Xac nhan dang ky hop dong TrustedHub</DisplayMessage>";

                string timestamp = CurrentTimeMillis().ToString();

                string data = username + password + signature + timestamp;
                string pkcs1Signature = getPKCS1Signature(data, P12Path, P12Key);
                cagCredential cag = new cagCredential();
                cag.username = username;
                cag.password = password;
                cag.signature = signature;
                cag.timestamp = timestamp;
                cag.pkcs1Signature = pkcs1Signature;

                //Get file data as byte array
                FileStream fs = new FileStream(file_source_pdf, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                long numBytes = new FileInfo(file_source_pdf).Length;
                byte[] buff = br.ReadBytes((int)numBytes);

                // Prepare request to send to server
                transactionInfo request = new transactionInfo();
                request.credentialData = cag;
                request.fileData = buff; //need to do
                request.xmlData = requestXML;

                processData dataToSend = new processData();
                dataToSend.transInfo = request;

                processDataResponse response = service.processData(dataToSend);

                // Write signed byte array to file
                int responseCode = Int32.Parse(getContent("ResponseCode", response.@return.xmlData));
                if(responseCode == 0) {
			        Debug.WriteLine("registered!");
			        Debug.WriteLine(response.@return.xmlData);
		        } else {
			        Debug.WriteLine("error: "+response.@return.xmlData);
		        }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
            Console.ReadLine();
	    }

        public void unregister(ClientWSService service)
        {
		try {
                string requestXML = "<Channel>" + channelName + "</Channel>\n"
                + "<User>" + customerUser + "</User>\n"
                + "<ID>01009090</ID>\n"
                + "<WorkerName>AgreementHandler</WorkerName>\n"
                + "<Action>UNREGISTRATION</Action>\n"
                + "<AgreementStatus>CANC</AgreementStatus>";

                string timestamp = CurrentTimeMillis().ToString();

                string data = username + password + signature + timestamp;
                string pkcs1Signature = getPKCS1Signature(data, P12Path, P12Key);
                cagCredential cag = new cagCredential();
                cag.username = username;
                cag.password = password;
                cag.signature = signature;
                cag.timestamp = timestamp;
                cag.pkcs1Signature = pkcs1Signature;

                //Get file data as byte array
                FileStream fs = new FileStream(file_source_pdf, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                long numBytes = new FileInfo(file_source_pdf).Length;
                byte[] buff = br.ReadBytes((int)numBytes);

                // Prepare request to send to server
                transactionInfo request = new transactionInfo();
                request.credentialData = cag;
                request.fileData = buff; //need to do
                request.xmlData = requestXML;

                processData dataToSend = new processData();
                dataToSend.transInfo = request;

                processDataResponse response = service.processData(dataToSend);

                // Write signed byte array to file
                int responseCode = Int32.Parse(getContent("ResponseCode", response.@return.xmlData));
                if(responseCode == 0) {
			        Debug.WriteLine("registered!");
			        Debug.WriteLine(response.@return.xmlData);
		        } else {
			        Debug.WriteLine("error: "+response.@return.xmlData);
		        }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
            Console.ReadLine();
	}
        

        private void signXml(ClientWSService service)
        {
            try
            {

                string file_source = "E:\\File\\FileToSign\\ok.xml";
                string file_destination = "E:\\File\\FileToSign\\ok_signed.xml";

                string requestXML = "<Channel>" + channelName + "</Channel>\n"
                + "<User>" + customerUser + "</User>\n"
                + "<ID>01009090</ID>\n"
                + "<FileType>xml</FileType>\n"
                + "<MetaData>\n"
                + "  <Method>SynchronousSign</Method>\n"
                + "</MetaData>\n"
                + "<WorkerName>MultiSigner</WorkerName>";

                string timestamp = CurrentTimeMillis().ToString();

                string data = username + password + signature + timestamp;
                string pkcs1Signature = getPKCS1Signature(data, P12Path, P12Key);
                cagCredential cag = new cagCredential();
                cag.username = username;
                cag.password = password;
                cag.signature = signature;
                cag.timestamp = timestamp;
                cag.pkcs1Signature = pkcs1Signature;

                //Get file data as byte array
                FileStream fs = new FileStream(file_source, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                long numBytes = new FileInfo(file_source).Length;
                byte[] buff = br.ReadBytes((int)numBytes);

                // Prepare request to send to server
                transactionInfo request = new transactionInfo();
                request.credentialData = cag;
                request.fileData = buff; //need to do
                request.xmlData = requestXML;

                processData dataToSend = new processData();
                dataToSend.transInfo = request;

                processDataResponse response = service.processData(dataToSend);

                Debug.WriteLine(response.@return.xmlData);
                // Write signed byte array to file
                string fileType = getContent("FileType", response.@return.xmlData);
                if (fileType.CompareTo("") != 0)
                {
                    File.WriteAllBytes(file_destination, response.@return.fileData);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
            Console.ReadLine();
        }

        private void signOffice(ClientWSService service)
        {
            try
            {

                string file_source = "E:\\File\\FileToSign\\ok.xlsx";
                string file_destination = "E:\\File\\FileToSign\\ok_signed111.xlsx";

                string requestXML = "<Channel>" + channelName + "</Channel>\n"
                + "<User>" + customerUser + "</User>\n"
                + "<ID>01009090</ID>\n"
                + "<FileType>doc</FileType>\n"
                + "<MetaData>\n"
                + "  <Method>SynchronousSign</Method>\n"
                + "</MetaData>\n"
                + "<WorkerName>MultiSigner</WorkerName>";

                string timestamp = CurrentTimeMillis().ToString();
                
                string data = username + password + signature + timestamp;
                string pkcs1Signature = getPKCS1Signature(data, P12Path, P12Key);
                cagCredential cag = new cagCredential();
                cag.username = username;
                cag.password = password;
                cag.signature = signature;
                cag.timestamp = timestamp;
                cag.pkcs1Signature = pkcs1Signature;
                
                //Get file data as byte array
                FileStream fs = new FileStream(file_source, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                long numBytes = new FileInfo(file_source).Length;
                byte[] buff = br.ReadBytes((int)numBytes);

                // Prepare request to send to server
                transactionInfo request = new transactionInfo();
                request.credentialData = cag;
                request.fileData = buff; //need to do
                request.xmlData = requestXML;

                processData dataToSend = new processData();
                dataToSend.transInfo = request;

                processDataResponse response = service.processData(dataToSend);

                Debug.WriteLine(response.@return.xmlData);
                // Write signed byte array to file
                string fileType = getContent("FileType", response.@return.xmlData);
                if (fileType.CompareTo("") != 0)
                {
                    File.WriteAllBytes(file_destination, response.@return.fileData);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
            Console.ReadLine();
        }

        private void signPdf(ClientWSService service)
        {
            try
            {
                string file_source = "E:\\File\\FileToSign\\ok.pdf";
                string file_destination = "E:\\File\\FileToSign\\ok_signed111.pdf";

                string requestXML = "<Channel>" + channelName + "</Channel>\n" + "<User>"
                + customerUser + "</User>\n" + "<ID>01009090</ID>\n"
                + "<FileType>pdf</FileType>\n" + "<MetaData>\n"
                + "  <Method>SynchronousSign</Method>\n"
                + "  <PageNo>1</PageNo>\n"
                + "  <Coordinate>50,500,550,680</Coordinate>\n"
                + "  <SignReason>Ký lần 2, sếp cho ý kiến</SignReason>\n"
                + "</MetaData>\n" + "<WorkerName>MultiSigner</WorkerName>";

                string timestamp = CurrentTimeMillis().ToString();

                string data = username + password + signature + timestamp;
                string pkcs1Signature = getPKCS1Signature(data, P12Path, P12Key);
                cagCredential cag = new cagCredential();
                cag.username = username;
                cag.password = password;
                cag.signature = signature;
                cag.timestamp = timestamp;
                cag.pkcs1Signature = pkcs1Signature;

                //Get file data as byte array
                FileStream fs = new FileStream(file_source, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                long numBytes = new FileInfo(file_source).Length;
                byte[] buff = br.ReadBytes((int)numBytes);

                // Prepare request to send to server
                transactionInfo request = new transactionInfo();
                request.credentialData = cag;
                request.fileData = buff; //need to do
                request.xmlData = requestXML;

                processData dataToSend = new processData();
                dataToSend.transInfo = request;

                processDataResponse response = service.processData(dataToSend);

                Debug.WriteLine(response.@return.xmlData);
                // Write signed byte array to file
                string fileType = getContent("FileType", response.@return.xmlData);
                if (fileType.CompareTo("") != 0)
                {
                    File.WriteAllBytes(file_destination, response.@return.fileData);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
            Console.ReadLine();
        }


        private static readonly DateTime Jan1st1970 = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        private static long CurrentTimeMillis()
        {
            return (long)(DateTime.UtcNow - Jan1st1970).TotalMilliseconds;
        }

        private static string getPKCS1Signature(string data, string key, string passkey)
        {
            MakeSignature mks = new MakeSignature(data, key, passkey);
            return mks.getSignature();
        }

        private static bool AlwaysGoodCert(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslpolicyerrors)
        {
            return true;
        }

        private static string getContent(string tagName, string xmlData)
        {
            string res = "";
            try
            {
                String startTag = "<" + tagName + ">";

                int hasTag = xmlData.IndexOf(startTag);
                if (hasTag != -1)
                {
                    String endTag = "</" + startTag.Substring(1);
                    int indexStart = xmlData.IndexOf(startTag) + startTag.Length;
                    int indexEnd = xmlData.IndexOf(endTag);
                    res = xmlData.Substring(indexStart, indexEnd - indexStart);
                }
            }
            catch (Exception e)
            {
                res = "";
            }
            return res;
        }
    }
}
