﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Org.BouncyCastle.Crypto;
using System.IO;
using System.Security.Cryptography;
using System.Runtime.Serialization;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Security;
using System.Security.Cryptography.X509Certificates;

namespace CAG360.ClientWS
{
    public class MakeSignature
    {   
        private String data;
        private String key;
        private String passKey;

        public MakeSignature(String data, String PriKeyPath, String PriKeyPass)
        {
                this.data = data;
                this.key = PriKeyPath;
                this.passKey = PriKeyPass;
        }

        public String getSignature()
        {
            RSACryptoServiceProvider key = GetKey();
            return Sign(this.data, key);
        }

        public static string Sign(string content, RSACryptoServiceProvider rsa)
        {
            RSACryptoServiceProvider crsa = rsa;
            byte[] Data = Encoding.UTF8.GetBytes(content); ;
            byte[] signData = crsa.SignData(Data, "sha1");
            return Convert.ToBase64String(signData);

        }
        private RSACryptoServiceProvider GetKey()
        {
            X509Certificate2 cert2 = new X509Certificate2(this.key, this.passKey);
            RSACryptoServiceProvider rsa = (RSACryptoServiceProvider)cert2.PrivateKey;
            return rsa;
        }
    }
}
